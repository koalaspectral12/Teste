@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo GERANDO EXE DO RELATORIO WHATSAPP
echo ========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo Python nao encontrado no Windows.
  echo Instale o Python e marque a opcao "Add Python to PATH".
  pause
  exit /b 1
)

python -m pip install --upgrade pip
python -m pip install pyinstaller

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist whatsapp_relatorio.spec del /q whatsapp_relatorio.spec
if exist whatsapp_relatorio.exe del /q whatsapp_relatorio.exe

python -m PyInstaller --noconfirm --onefile --windowed --name whatsapp_relatorio app.py

if not exist dist\whatsapp_relatorio.exe (
  echo.
  echo Falha ao gerar o EXE.
  pause
  exit /b 1
)

copy /y dist\whatsapp_relatorio.exe . >nul

echo.
echo EXE gerado com sucesso:
echo %cd%\whatsapp_relatorio.exe
echo.
pause
endlocal
